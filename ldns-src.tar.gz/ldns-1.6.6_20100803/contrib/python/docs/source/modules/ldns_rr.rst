Class ldns_rr
================================


..	automodule:: ldns

Class ldns_rr
------------------------------
.. autoclass:: ldns_rr
	:members:
	:undoc-members:

Class ldns_rr_descriptor
------------------------------
.. autoclass:: ldns_rr_descriptor
	:members:
	:undoc-members:

